import BackgroundScreen from '@/components/BackgroundScreen';

export default function PhotoSearchPage() {
  return (
    <div className="page text-[#000000]">
      <BackgroundScreen/>
    </div>
  );
}
